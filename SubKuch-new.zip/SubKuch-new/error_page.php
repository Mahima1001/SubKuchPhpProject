<style>

body{
	background-image:url('Error-Page.png');
}
#button{
	background-color:orange;
	color:white;
	margin-top:414px;
	margin-left:300px;
	width:150px;
	padding:10px;
	border-radius:5px;
}
</style>

<html>
	<body>
		<form action="main.php">
			<input id="button" type="submit" value="Take me Home">
		</form>
	</body>
</html>