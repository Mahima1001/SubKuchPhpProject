#include<stdio.h>
#include<conio.h>
#include"d_b.h"

int main()
{
	int m,n,i=0;
	
	printf("\nEnter the first number: ");
	scanf("%d",&n);
    d_b(n);
    
	return 0;
}
