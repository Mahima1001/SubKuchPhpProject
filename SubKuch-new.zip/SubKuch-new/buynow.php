<?php
session_start();
$_SESSION['speci']='false';
header("location:detail.php");
?>