<html>
	<head>
	<title>Login Form</title>
	</head>
	<body>
		<h2>Login Form</h2>
		<form method="post" action="checklogin.php">
			User Id: <input type="text" name="uid"><br>
			Password: <input type="password" name="pw"><br>
			<input type="submit" value="Login">
		</form>
	</body>
</html>
