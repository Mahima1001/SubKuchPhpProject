<script>
	<?php
	session_start();
	echo $_SESSION["username"];
	if($_SESSION["logout"]=="logout"){
		?> alert("You have Sucessfully logged out");<?php
		$_SESSION["logout"] = "loggedin";
	}
	if($_SESSION["username"]=='') $_SESSION["username"] ="username";
	$_SESSION['login']="";
	?>
</script>


<html>
	<head>
		<title> BLOG SITE</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" type="text/css" href="main1.css">
		<link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
		<style>
.mySlides {display:none;}
</style>
	</head>
	
	<body>
	
		<div id="pink">
		
  
			<div id="header">
				<img id ="left" src="logo.png" OnClick="main.php">
				<div id ="right">
					<a class="abc" href="all_blog.php">Explore Blogs</a>
					<a class="abc" href="contact.php">Contact Us</a>
					<?php
						if($_SESSION["username"] !="username" && $_SESSION["username"]!="Admin"){?>
							<a class="abc" href="user_page.php" title="Home"><?PHP echo "Welcome ".$_SESSION["username"]."!!";?></a>
							<a class="abc" href="logout.php">Log Out</a>
						<?php  }
						else if($_SESSION["username"] !="username" && $_SESSION["username"]=="Admin"){?>
							<a class="abc" href="admin.php" title="Home"><?PHP echo "Welcome ".$_SESSION["username"]."!!";?></a>
							<a class="abc" href="logout.php">Log Out</a>
						<?php  }
						else{ ?>
							<a class="abc" href="login.php">Sign In</a>
					<?php } ?>
				</div>
			</div>
		
			<img class="mySlides" src="picslider1.jpg" style="width:100%; height:300px;">
			<img class="mySlides" src="pic.jpg" style="width:100%; height:300px;">
			<img class="mySlides" src="picslider2.jpg" style="width:100%; height:300px;">
			<img class="mySlides" src="picslider3.jpg" style="width:100%; height:300px;">
			<img class="mySlides" src="picslider4.jpg" style="width:100%; height:300px;">
			<img class="mySlides" src="picslider5.jpg" style="width:100%; height:300px;">
			<img class="mySlides" src="picslider6.jpg" style="width:100%; height:300px;">
			<br>
<script>
var myIndex = 0;
carousel();

function carousel() {
    var i;
    var x = document.getElementsByClassName("mySlides");
    for (i = 0; i < x.length; i++) {
       x[i].style.display = "none";
    }
    myIndex++;
    if (myIndex > x.length) {myIndex = 1}
    x[myIndex-1].style.display = "block";
    setTimeout(carousel, 3000); // Change image every 2 seconds
}
</script>
		<div style="width:100%; margin:2%; height:250px;">
		<div style="float:left; width:68%; height: 250px;">
		<img src="offerpic.jpg" style="width:100%; height:250px;">
		</div>
		<div style=" float:right; width:30%; height: 250px;  background-color: red;">
		
		</div>
		<div style=" float:right; width:30%; height: 250px;  background-color: red;">
		
		</div>
		</div>
		<br>
		<h3>Top mobiles with offers</h3>
		<div style="width:100%; margin:2%; height:300px;">
		
		<div style="float:left; width:17%; height: 300px;">
    	 <img class="mySlides2" src="phone1.jpg" style="width:100%;height:220px;">
		 <a class="w3-btn-floating" style="position:absolute;top:45%;left:0" onclick="plusDivs(-1)"><</a>
		</div>
		<div style="float:left; width:17%; height: 300px;">
		<img class="mySlides2" src="phone1.jpg" style="width:100%;height:220px;">
		</div>
		<div style="float:left; width:17%; height: 300px;">
		<img class="mySlides2" src="phone1.jpg" style="width:100%;height:220px;">
		</div>
		<div style="float:left; width:17%; height: 300px;">
		<img class="mySlides2" src="phone1.jpg" style="width:100%;height:220px;">
		<a class="w3-btn-floating" style="position:absolute;top:45%;right:0" onclick="plusDivs(1)">></a>
		</div>
		
		
		</div>
		</div>
		
		
		<br />
		<div id="map"><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3720.623800701072!2d72.78290001417079!3d21.16736458592344!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be04dede93ea7d1%3A0x238a612304b01088!2sSardar+Vallabhbhai+National+Institute+of+Technology!5e0!3m2!1sen!2sin!4v1469644481263" width="96%" height="500" frameborder="0" style="border:0" allowfullscreen></iframe>
		</div>
		<br />
	<body>
</html>
<script>
<?php
	if(isset($_SESSION["delete"]) && $_SESSION["delete"]=="yes"){
		?>alert("Successfully Deleted  :)"); <?php
		$_SESSION["delete"]="no";
	}
	if(isset($_SESSION["delete"]) && $_SESSION["delete"]=="yes"){
		?>alert("Error!"); <?php
		$_SESSION["delete"]="no";
	}
?>
</script>
<?php
	if(isset($_SESSION["register"]) && $_SESSION["register"]=="yes"){
		?><script>alert("You had Successfully created your account :)");</script><?php
		$_SESSION["register"]="no";
	}
?>