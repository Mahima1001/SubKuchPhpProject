<?php
session_start();
$category = $_SESSION['item_cat'];
$_SESSION['checksave']="";
$_SESSION['checkupdate']="";
?>
<html>
<head>
<link rel="stylesheet" type="text/css" href="main1.css">
<style>
	
	#main{
		width:100%;
		height : 350px;
		margin-left: 3%;
		margin-top: 5%;
		
		
	}
	
	#submain{
		width: 22%;
		height:350px;
		margin: 0px;
		float:left;
		margin-top: 5%;
		margin-right:2%
	}
	
	
	
	#image{
		width:100%;
		height: 70%;
		margin-top:0px;
		position:relative;
	}
	
	#desc{
		width: 100%;
		height : 30%;
		margin-top:0px;
	}
	
	#name{
		width:100%;
		height: 33%;
		
	}
	
	#button{
		width:100%;
		height:33%;
		align:center;
		
	}
	
	.allowORdeny{
		float:right;
		margin:5px;
	}
	
	.allowblog{
		background-color:#663500;
		color:white;
		padding:2px;
		width:90px;
		height:28px;
	}
	
	h2{
		position: absolute; 
   top: 50px; 
   text-align:center;
   
	}
	
	h2 span { 
   color: red; 
   font: bold  Helvetica, Sans-Serif; 
   letter-spacing: -1px;  
   background: rgb(0, 0, 0); /* fallback color */
   background: rgba(0, 0, 0, 0.7);
   padding: 10px; 
}
	
	
</style>
</head>
<body>

<?php

if(strcmp($_SESSION['added_to_cart'],"true")==0)
{
	?><script>alert("<?php echo'Item '.$_SESSION['get_name'].' added successfully to your cart'; ?>");</script><?php
	
}
$_SESSION['added_to_cart']="";
?>

<div id="header">
				<img id ="left" src="logo.png" OnClick="main.php">
				<div id ="right">
					
					<a class="abc" href="contact.php">Contact Us</a>
					<a class="abc" href="additem.php?category=<?php echo $category; ?>">Add Item</a>
					<?php
						if($_SESSION["username"] !="username" && $_SESSION["username"]!="Admin"){?>
							<a class="abc" href="user_page.php" title="Home"><?PHP echo "Welcome ".$_SESSION["username"]."!!";?></a>
							<a class="abc" href="logout.php">Log Out</a>
						<?php  }
						else if($_SESSION["username"] !="username" && $_SESSION["username"]=="Admin"){?>
							<a class="abc" href="admin.php" title="Home"><?PHP echo "Welcome ".$_SESSION["username"]."!!";?></a>
							<a class="abc" href="logout.php">Log Out</a>
						<?php  }
						else{ ?>
							<a class="abc" href="login.php">Sign In</a>
					<?php } ?>
				</div>
			</div>
			
			<img class="mySlides" src="picslider1.jpg" style="width:100%; height:300px;">
			<img class="mySlides" src="pic.jpg" style="width:100%; height:300px;">
			<img class="mySlides" src="picslider2.jpg" style="width:100%; height:300px;">
			<img class="mySlides" src="picslider3.jpg" style="width:100%; height:300px;">
			<img class="mySlides" src="picslider4.jpg" style="width:100%; height:300px;">
			<img class="mySlides" src="picslider5.jpg" style="width:100%; height:300px;">
			<img class="mySlides" src="picslider6.jpg" style="width:100%; height:300px;">
			<br>
<script>
var myIndex = 0;
carousel();

function carousel() {
    var i;
    var x = document.getElementsByClassName("mySlides");
    for (i = 0; i < x.length; i++) {
       x[i].style.display = "none";
    }
    myIndex++;
    if (myIndex > x.length) {myIndex = 1}
    x[myIndex-1].style.display = "block";
    setTimeout(carousel, 3000); // Change image every 2 seconds
}
</script>

			
			<?php
$con = mysqli_connect("localhost","root","","SubKuch");
if (!$con)
  {
  die('Could not connect: ' . mysqli_error());
  }
  echo '<div id= "main">';
  
  $query_item="SELECT id, name, image , description , quantity, price FROM image_items where category = '$category'";
  $result_item=mysqli_query($con,$query_item);
  while($row_item = mysqli_fetch_assoc($result_item))
  {
	  $image_item= $row_item['image'];
	  echo '<div id = "submain">';
	  echo '<div id = "image">';
	  echo '<img style="width:100%; height:100%;" src="' . $image_item . ' " alt="Your Image"/>';
	  if($row_item['quantity']==0)
	  {
		  echo '<h2><span> STOCK OUT! </span></h2>';
	  }
	  echo '</div>';
	  echo '<div id= "desc">';
	  echo '<div id = "name">';
	  echo 'Item - '.$row_item['name'];
	  echo '</div>';
	  echo '<div id = "name">';
	  echo 'Cost - ' . $row_item['price'];
	  echo '</div>';
	  echo '<div id = "button">';
	  echo  '<div class="allowORdeny">';
	  
		 if($row_item['quantity']==0)
	  {
		  echo '<form name="myForm2" enctype="multipart/form-data" onsubmit="" action="" method="post">';
							echo '<input type="hidden" name="itemid" value='.$row_item["id"].'>';
							echo '<input class="allowblog" type="submit" value="Add To Cart" name="addtocart" disabled/>';
						echo "</form>";
						
	  }
	  else{
				echo '<form name="myForm2" enctype="multipart/form-data" onsubmit="" action="addtocart.php" method="post">';
							echo '<input type="hidden" name="itemid" value='.$row_item["id"].'>';
							echo '<input class="allowblog" type="submit" value="Add To Cart" name="addtocart"/>';
						echo "</form>";
	  }
					echo "</div>";
					echo  '<div class="allowORdeny">';
				echo '<form name="myForm2" enctype="multipart/form-data" onsubmit="" action="detail.php" method="post">';
							echo '<input type="hidden" name="itemid" value='.$row_item["id"].'>';
							echo '<input class="allowblog" type="submit" value="See Detail" name="seedetail"/>';
						echo "</form>";
					echo "</div>";
					
	  echo '</div>';
	  echo '</div>';
	  echo '</div>';
	  
	 
  }
   echo '</div>';
  mysqli_close($con);
  ?>
  
  

  </body>
</html>


