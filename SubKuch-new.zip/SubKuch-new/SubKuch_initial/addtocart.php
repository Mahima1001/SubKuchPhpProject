<?php
session_start();
$username=$_SESSION['username'];
?>
<?php
$itemid=$_POST['itemid'];
$con = mysqli_connect("localhost","root","","SubKuch");
if (!$con)
  {
  die('Could not connect: ' . mysqli_error());
  }
  $query_get_name="SELECT name FROM image_items where id= '$itemid'";
  $result_get_name=mysqli_query($con,$query_get_name);
  $row_get_name = mysqli_fetch_assoc($result_get_name);
  $_SESSION['get_name']=$row_get_name['name'];
  $query="INSERT INTO buyitem(username,item_id)VALUES('$username','$itemid')";
  $result=mysqli_query($con,$query);
  $query_quantity= "Update image_items set quantity= quantity-1 where id= '$itemid'";
  $result_quantity=mysqli_query($con,$query_quantity);
  $_SESSION['added_to_cart']="true";
  header("location:buyitems.php");
  mysqli_close($con);
?>

