<?php
session_start();
$itemid= $_POST['itemid'];
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" http://www.w3.org/TR/html4/loose.dtd>
<html xmlns="http://www.w3.org/1999/xhtml" >
<head>
<script src="js/jquery-1.6.js" type="text/javascript"></script>
<script src="js/jquery.jqzoom-core.js" type="text/javascript"></script>

<link rel="stylesheet" href="css/jquery.jqzoom.css" type="text/css">
<style type"text/css">

body{
	margin:0px;
	padding:0px;
	font-family:Arial;
	}
a img,:link img,:visited img {
	border: none; 
	}
table {
	border-collapse: collapse; 
	border-spacing: 0; 
	}
:focus { 
outline: none;
 }
*{
	margin:0;
	padding:0;
	}
p, blockquote, dd, dt{
	margin:0 0 8px 0;
	line-height:1.5em;
	}
fieldset {
	padding:0px;
	padding-left:7px;
	padding-right:7px;
	padding-bottom:7px;
	}
fieldset legend{
	margin-left:15px;
	padding-left:3px;
	padding-right:3px;
	color:#333;
	}
dl dd{
	margin:0px;
	}
dl dt{}

.clearfix:after{
	clear:both;
	content:".";
	display:block;
	font-size:0;
	height:0;
	line-height:0;
	visibility:hidden;
	}
.clearfix{
	display:block;
	zoom:1}


ul#thumblist{display:block;}
ul#thumblist li{
	float:left;
	margin-right:2px;
	list-style:none;
	}
ul#thumblist li a{
	display:block;
	border:1px solid #CCC;
	}
ul#thumblist li a.zoomThumbActive{
    border:1px solid red;
}

.jqzoom{

	text-decoration:none;
	float:left;
}

#button{
		width:100%;
		height:33%;
		align:center;
		
	}
	
	.allowORdeny{
		float:left;
		margin:10px;
		margin-left:14px;
	}
	
	.allowblog{
		background-color:black;
		color:white;
		padding:2px;
		width:90px;
		height:35px;
	}

#desc{
	float:right;
	width:300px;
	height:450px;
	margin-top:-250px;
	position:relative;
	margin-right:80px;
}

p{
	
	font-size:15px;
}


</style>
<script type="text/javascript">

$(document).ready(function() {
	$('.jqzoom').jqzoom({
            zoomType: 'standard',
            lens:true,
            preloadImages: false,
            alwaysOn:false
        });
	
});


</script>
</head>

<body>

<?php
$con = mysqli_connect("localhost","root","","SubKuch");
if (!$con)
  {
  die('Could not connect: ' . mysqli_error());
  }
  
  $query= "SELECT image,name,description,category,price,colour,quantity FROM image_items WHERE id= '$itemid'";
  $result=mysqli_query($con,$query);
  $row = mysqli_fetch_assoc($result);
  $image=$row['image'];
  $name=$row['name'];
  $desc=$row['description'];
  $category=$row['category'];
  $price=$row['price'];
  $colour=$row['colour'];
  $quantity=$row['quantity'];
?>
<?php
if($quantity==0)
{
	echo'<h1 style="color:red; text-align:center; margin-bottom:-50px; margin-top:10px;">Not In Stock !</h1>';
}

?>
<div class="clearfix" id="content" style="margin-top:100px;margin-left:350px; height:500px;width:700px;" >
    <div class="clearfix" style="float:left;">
        <a href="<?php echo $image; ?>" class="jqzoom" rel='gal1'  title="triumph" >
		<?php echo '<img style="width:35%; height:50%; border: 4px solid #666;" src="' . $image . ' " title="triumph" alt="Your Image"/>'; ?>
        </a>
    </div>
	
	<div id= "button">
	<?php
			if($quantity==0)
				{
					?>
					<div class="allowORdeny">
		
	
				<form name="myForm2" enctype="multipart/form-data" onsubmit="" action="detail.php" method="post">
							<input class="allowblog" type="submit" value="Add to cart" name="addtocart" disabled/>
						</form>
					</div>
					
				<div class="allowORdeny">
				<form name="myForm2" enctype="multipart/form-data" onsubmit="" action="buynow.php" method="post">
							<input class="allowblog" type="submit" value="Buy Now" name="buynow" disabled/>
						</form>
					</div>
					<?php
				}
				
				else{
					?>
				<div class="allowORdeny">
		
	
				<form name="myForm2" enctype="multipart/form-data" onsubmit="" action="detail.php" method="post">
							<input class="allowblog" type="submit" value="Add to cart" name="addtocart"/>
						</form>
					</div>
					
				<div class="allowORdeny">
				<form name="myForm2" enctype="multipart/form-data" onsubmit="" action="buynow.php" method="post">
							<input class="allowblog" type="submit" value="Buy Now" name="buynow"/>
						</form>
					</div>
					<?php
				}
				?>
					
	</div>
	
	<div id= "desc">
	<br>
	<h3><u>Specifications</u></h3>
	<br><hr><br>
	<p>Product Model - <?php echo $name;?></p>
	<p>Category - <?php echo $category;?></p>
	<p>Colour - <?php echo $colour;?></p>
	<p>Quantity- <?php echo $quantity;?></p>
	<p>Description - <?php echo $desc;?></p>
	<h5>Cost - <?php echo $price;?></h5>
	
	</div>
	
</div>

</body></html>