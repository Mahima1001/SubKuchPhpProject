<?php

session_start();

?>



<html>
<head>
</head>
<body>
<form action="login1.php" method="post">

Username : <input type="text" name="uname">
<br/>
<br/>
Password : <input type="password" name="password">
<br/>
<br/>
<input type="submit" value="login">

</form>
</body>
</html>